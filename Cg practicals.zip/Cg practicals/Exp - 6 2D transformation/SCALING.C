	#include <graphics.h>
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <math.h>


    int  main(void)
   {
    int gd = DETECT, gm=0;
    float sx,sy;
     float p[3][3]={{100,200,1},{100,200,1},{1,1,1}};
     float t[3][3]={{1,0,0},{0,1,0},{0,0,1}};
     float  s[3][3]={0};int i,j,k;
     initgraph(&gd,&gm, "C:\\Tc\\BGI");
     printf("Enter the values of sx and sy :");
     scanf("%f %f",&sx,&sy);
     //setcolor(RED);
     rectangle((int)p[0][0],(int)p[1][0],(int)p[0][1],(int)p[1][1]);
     /*line(p[0][0],p[1][0],p[0][1],p[1][1]);
     line(p[0][0],p[1][0],p[0][2],p[1][2]);
     line(p[0][2],p[1][2],p[0][1],p[1][1]);*/
     t[0][0]=sx;
     t[1][1]=sy;
     for(i=0;i<3;i++)
     {
	for(j=0;j<3;j++)
		{
			for(k=0;k<3;k++)
			{
				s[i][j]=s[i][j]+(t[i][k]*p[k][j]);
			}
		}
     }
     //setcolor(GREEN);
     rectangle((int)s[0][0],(int)s[1][0],(int)s[0][1],(int)s[1][1]);
     /*line(tr[0][0],tr[1][0],tr[0][1],tr[1][1]);
     line(tr[0][0],tr[1][0],tr[0][2],tr[1][2]);
     line(tr[0][2],tr[1][2],tr[0][1],tr[1][1]);*/
     getch();
     closegraph();
     return 0;
    }