#include <graphics.h>
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <math.h>


    int  main(void)
   {
    int gd = DETECT, gm=0;
    float sx,sy;
     float p[3][3]={{300,400,1},{300,400,1},{1,1,1}};
     float t[3][3]={{1,0,0},{0,1,0},{0,0,1}};
     float  tr[3][3]={0};int i,j,k;
     int angle;float rad;
     initgraph(&gd,&gm, "C:\\Tc\\BGI");
     printf("Enter angle of rotation (red line original):");
     scanf("%d",&angle);
     rad= angle*3.142/180;
     setcolor(RED);
     line((int)p[0][0],(int)p[1][0],(int)p[0][1],(int)p[1][1]);
     /*line(p[0][0],p[1][0],p[0][1],p[1][1]);
     line(p[0][0],p[1][0],p[0][2],p[1][2]);
     line(p[0][2],p[1][2],p[0][1],p[1][1]);*/
     t[0][0]=cos(rad);
     t[0][1]=-sin(rad);
     t[1][0]=sin(rad);
     t[1][1]=cos(rad);
     for(i=0;i<3;i++)
     {
	for(j=0;j<3;j++)
		{
			for(k=0;k<3;k++)                                                                                                                                                                                                                                                                                                                                                                               																																																																														
			{
				tr[i][j]=tr[i][j]+(t[i][k]*p[k][j]);
			}
		}
     }
     setcolor(GREEN);
     line((int)tr[0][0],(int)tr[1][0],(int)tr[0][1],(int)tr[1][1]);
     /*line(tr[0][0],tr[1][0],tr[0][1],tr[1][1]);
     line(tr[0][0],tr[1][0],tr[0][2],tr[1][2]);
     line(tr[0][2],tr[1][2],tr[0][1],tr[1][1]);*/
     getch();
     closegraph();
     return 0;
    }