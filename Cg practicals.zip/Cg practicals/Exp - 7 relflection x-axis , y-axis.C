#include<graphics.h>
#include<conio.h>
#include<math.h>

void main(){
    
    int gd=DETECT,gm=0;
    int x1,y1,x2,y2;
    int i,j,k,midy,yf1,yf2,midx,xf1,xf2;
    detectgraph(&gd,&gm);
    initgraph(&gd,&gm,"c:\\tc\\BGI");
    printf("\n Enter x1,y1,x2,y2    ");
    scanf("%d %d %d %d",&x1,&y1,&x2,&y2);
    line(0,getmaxy()/2,getmaxx(),getmaxy()/2);
    line(getmaxx()/2,0,getmaxx()/2,getmaxy());

    line(x1,y1,x2,y2);
    midy=getmaxy()/2;
    yf1=midy+(midy-y1);
    yf2=midy+(midy-y2);

    printf("\n X-axis reflection Green color");
    setcolor(GREEN);
    line(x1,yf1,x2,yf2);

    //y axis reflection
    
    // midx=getmaxx()/2;
    // xf1=midx+(midx-x1);
    // xf2=midx+(midx-x2);
    // printf("\n Y-axis reflection in BLUE color");
    // setcolor(BLUE);
    // line(xf1,y1,xf2,y2);

    getch();
    closegraph();
    }


