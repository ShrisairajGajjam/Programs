
#include<stdio.h>
#include<conio.h>
#include<math.h>
#include<process.h>
#include<graphics.h>
int x1,x2,y1,y2,depth;
void rotateZ();
 void main()
{
    int gd=DETECT,gm,c;
    initgraph(&gd,&gm,"C:\\tc\\bgi");
    printf("\n3D Transformation Rotating\n\n");
    printf("\nEnter 1st top value(x1,y1):");
    scanf("%d%d",&x1,&y1);
    printf("Enter right bottom value(x2,y2):");
    scanf("%d%d",&x2,&y2);
    depth=(x2-x1)/4;
    bar3d(x1,y1,x2,y2,depth,1);
    rotateZ();
    getch();
}

void rotateZ()
{
    float t;
    int xr1,xr2,yr1,yr2,dep;
    printf("Enter the angle to rotate=");
    scanf("%f",&t);
    t=t*(3.14/180);
    xr1=x1*cos(t)-(y1)*sin(t);
    xr2=x2*cos(t)-(y2)*sin(t);
    yr1=x1*sin(t)+(y1)*cos(t);
    yr2=x2*sin(t)+(y2)*cos(t);
    if(xr2>xr1)
       dep=(xr2-xr1)/4;
    else
      dep=(xr1-xr2)/4;
      setcolor(BLUE);
    bar3d(xr1,yr1,xr2,yr2,dep,1);
       }