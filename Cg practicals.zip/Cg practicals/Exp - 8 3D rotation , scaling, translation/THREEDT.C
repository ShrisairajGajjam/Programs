// 3d tranlation

#include<stdio.h>
#include<conio.h>
#include<graphics.h>
#include<math.h>
int maxx,maxy,midx,midy;
void axis()
{
cleardevice();
line(midx,0,midx,maxy);
line(0,midy,maxx,midy);
}
void main()
{
int tx,ty,tz,x1,x2,y1,y2;
int gd=DETECT,gm;
detectgraph(&gd,&gm);
initgraph(&gd,&gm,"c:\\tc\\bgi");
maxx=getmaxx();
maxy=getmaxy();
midx=maxx/2;
midy=maxy/2;

axis();

bar3d(midx+50,midy-100,midx+60,midy-90,10,1);

printf("Enter translation factor tx ty tz        ");
scanf("%d%d%d",&tx,&ty,&tz);
printf("After translation:");
bar3d(midx+tx+50,midy-(ty+100),midx+tx+60,midy-(ty+90),10,1);
//bar3d(midx+tx+50,midy-(ty+100),midx+tx+60,midy-(ty+90),10+tz,1);
getch();
closegraph();
}