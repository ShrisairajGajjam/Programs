#include <graphics.h>
#include <stdio.h>
#include <math.h>
#include <dos.h>
 
void main( )
{
	float x,y,x1,y1,x2,y2,dx,dy,xinc,yinc,step;
	int k,gd=DETECT,gm=0;

	initgraph(&gd,&gm,"c:\\tc\\bgi");

	printf("Enter the value of x1 and y1 : ");
	scanf("%f%f",&x1,&y1);
	printf("Enter the value of x2 and y2: ");
	scanf("%f%f",&x2,&y2);

	dx=abs(x2-x1);
	dy=abs(y2-y1);

	if(dx>=dy)
		step=dx;
	else
		step=dy;

	xinc=dx/step;
	yinc=dy/step;

	x=x1;
	y=y1;

	k=1;
	while(k<=step)
	{
		putpixel(x+0.5,y+0.5,RED);
		x=x+xinc;
		y=y+yinc;
		k=k+1;
//		delay(100);
	}

	getch();
	closegraph();
}