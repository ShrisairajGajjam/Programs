#include <graphics.h>
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <math.h>

    void    EightWaySymmetricPlot(int xc,int yc,int x,int y)
   {
    putpixel(x+xc,y+yc,RED);
    putpixel(x+xc,-y+yc,YELLOW);
    putpixel(-x+xc,-y+yc,GREEN);
    putpixel(-x+xc,y+yc,BLUE);
    putpixel(y+xc,x+yc,10);
    putpixel(y+xc,-x+yc,5);
    putpixel(-y+xc,-x+yc,15);
    putpixel(-y+xc,x+yc,6);
   }

    int  main(void)
   {
    /* request auto detection */
    int xc,yc,r,gd = DETECT, gm=0;
     int x=0,y,p;
    /* initialize graphics and local variables */
     initgraph(&gd,&gm, "C:\\Tc\\BGI");

      printf("Enter the values of xc and yc :");
       scanf("%d%d",&xc,&yc);
       printf("Enter the value of radius  :");
	scanf("%d",&r);
	y=r;
	p=3-(2*r);

    EightWaySymmetricPlot(xc,yc,x,y);

    while(x<=y)
     {
      if(p<=0)
	     {
		p=p+(4*x)+6;
	     }
     else
	{
		p=p+(4*x)-(4*y)+10;
		y=y-1;
	      }
       x=x+1;
       EightWaySymmetricPlot(xc,yc,x,y);
       delay(500);
      }




     getch();
     closegraph();
     return 0;
    }